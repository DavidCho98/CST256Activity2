@extends('layouts/layout')

@section('content')
    <body>
        <h1>Contact</h1>
            <ul>Please dont try to contact us cus we dont have contact info..</ul>
    </body>

    @endsection
