@extends('layouts/layout')

@section('content')
    <body>
        <h1>About us</h1>
            <ul>Dont ask.. we dont even know who we are</ul>
    </body>
@endsection
