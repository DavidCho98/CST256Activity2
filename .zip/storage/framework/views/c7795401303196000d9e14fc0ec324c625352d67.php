<?php $__env->startSection('content'); ?>
    <body>
        <h1>About us</h1>
            <ul>Dont ask.. we dont even know who we are</ul>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Testing\resources\views/about.blade.php ENDPATH**/ ?>