<?php $__env->startSection('content'); ?>

    <h1>Contact</h1>
    <ul>Please dont try to contact us cus we dont have contact info..</ul>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Testing\resources\views/contact.blade.php ENDPATH**/ ?>